{-# LANGUAGE OverloadedStrings #-}
module Main where

--import Book
import Bookdb
import Web.Scotty
import Data.Aeson.Types()
import Control.Monad.IO.Class
import Database.PostgreSQL.Simple
import Network.Wai.Middleware.Cors

import Network.Wai (Middleware)

allowCors :: Middleware
allowCors = cors (const $ Just appCorsResourcePolicy)
appCorsResourcePolicy :: CorsResourcePolicy
appCorsResourcePolicy =
    simpleCorsResourcePolicy
        { corsMethods = ["DELETE", "GET", "POST"]
        , corsRequestHeaders = ["Authorization", "Content-Type"]
        }

main :: IO ()
main = do
--  conn <- connectPostgreSQL "host='' dbname='' port=5432 user= password="
  conn <- "host='95.217.219.129' dbname='bookdb' port=5432 user=ubook password=ub7414"

  scotty 8030 $ do
    middleware allowCors

    get "/api/v1/books" $ do
      books <- liftIO $ gelAllBooks conn
      json books
--
--    get "/api/v1/books/:name" $ do
--      bookName <- param "name"
--      booksWithName <- liftIO $ getBookByName conn bookName
--      json booksWithName
--
--    post "/api/v1/books" $ do
--      newBook <- jsonData :: ActionM Book
--      _ <- liftIO $ saveBook conn newBook
--      books <- liftIO $ gelAllBooks conn
--      json books
--
--    delete "/api/v1/books" $ do
--      bookForDelete <- jsonData :: ActionM Book
--      _ <- liftIO $ deleteBook conn bookForDelete
--      books <- liftIO $ gelAllBooks conn
--      json books
